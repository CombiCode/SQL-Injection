
import React, { useState } from 'react';
import { ScenarioCard } from './components/ScenarioCard';
import { LOGIN_SCENARIO_DATA, SEARCH_SCENARIO_DATA } from './constants';
import type { ScenarioData } from './types';

const SCENARIOS: ScenarioData[] = [LOGIN_SCENARIO_DATA, SEARCH_SCENARIO_DATA];

const App: React.FC = () => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(SCENARIOS[0].id);

  const selectedScenario = SCENARIOS.find(s => s.id === selectedScenarioId);

  return (
    <div className="min-h-screen container mx-auto p-4 md:p-8 antialiased">
      <header className="mb-8 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-blue-600 dark:text-blue-400">
          SQL Injection Vulnerability & Fix Visualizer
        </h1>
        <p className="mt-2 text-lg text-gray-600 dark:text-gray-400">
          Understanding how to prevent SQL injection attacks through practical examples.
        </p>
      </header>

      <nav className="mb-8 flex justify-center space-x-2 md:space-x-4">
        {SCENARIOS.map(scenario => (
          <button
            key={scenario.id}
            onClick={() => setSelectedScenarioId(scenario.id)}
            className={`px-4 py-2 md:px-6 md:py-3 rounded-lg font-semibold transition-all duration-200 ease-in-out
                        ${selectedScenarioId === scenario.id 
                          ? 'bg-blue-600 text-white shadow-lg transform scale-105' 
                          : 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-gray-600'
                        }`}
          >
            {scenario.title.split(' SQL')[0]} {/* Shorten title for button */}
          </button>
        ))}
      </nav>

      <main>
        {selectedScenario ? (
          <ScenarioCard scenario={selectedScenario} />
        ) : (
          <p className="text-center text-red-500">Selected scenario not found.</p>
        )}
      </main>

      <footer className="mt-12 pt-8 border-t border-gray-300 dark:border-gray-700 text-center">
        <p className="text-sm text-gray-500 dark:text-gray-400">
          This visualizer is for educational purposes only. Always consult security professionals for production systems.
        </p>
         <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          Crafted with React, TypeScript, and Tailwind CSS.
        </p>
      </footer>
    </div>
  );
};

export default App;
