
import React from 'react';
import type { CodeSnippetContent } from '../types';

interface CodeDisplayProps {
  snippet: CodeSnippetContent;
}

export const CodeDisplay: React.FC<CodeDisplayProps> = ({ snippet }) => {
  const { language, code, description, fileName } = snippet;

  return (
    <div className="my-4 rounded-lg shadow-md overflow-hidden bg-gray-800 dark:bg-black/50">
      {fileName && (
        <div className="bg-gray-700 dark:bg-gray-800 text-gray-200 dark:text-gray-300 px-4 py-2 text-sm font-mono border-b border-gray-600 dark:border-gray-700">
          {fileName}
        </div>
      )}
      {description && (
        <p className="px-4 pt-3 pb-1 text-sm text-gray-300 dark:text-gray-400 italic">{description}</p>
      )}
      <pre className="p-4 text-sm leading-relaxed overflow-x-auto">
        <code className={`language-${language} text-gray-100 dark:text-gray-200`}>
          {code.trim()}
        </code>
      </pre>
    </div>
  );
};
