
import React from 'react';
import type { ScenarioData, InputOutputExample, FlowStep } from '../types';
import { CodeDisplay } from './CodeDisplay';
import { Section } from './Section';

interface ScenarioCardProps {
  scenario: ScenarioData;
}

const InputOutputDisplay: React.FC<{ example: InputOutputExample }> = ({ example }) => (
  <div className={`my-4 p-4 border rounded-lg ${example.isHarmful ? 'border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-900/30' : 'border-green-300 dark:border-green-700 bg-green-50 dark:bg-green-900/30'}`}>
    <h4 className="font-semibold text-lg mb-2 text-gray-800 dark:text-gray-100">{example.label}</h4>
    {example.inputDescription && <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">{example.inputDescription}</p>}
    <CodeDisplay snippet={{ code: example.input, language: example.inputLanguage || 'text', description: 'Input:' }} />
    {example.outputDescription && <p className="text-sm text-gray-600 dark:text-gray-400 mt-3 mb-1">{example.outputDescription}</p>}
    <CodeDisplay snippet={{ code: example.output, language: example.outputLanguage || 'text', description: 'Output / Result:' }} />
  </div>
);

const FlowDiagramDisplay: React.FC<{ title: string, description: string, steps: FlowStep[] }> = ({ title, description, steps }) => (
  <Section title={title} level={3}>
    <p className="text-sm mb-4">{description}</p>
    <div className="space-y-3">
      {steps.map((step, index) => (
        <div key={index} className="flex items-start space-x-3">
          <div className={`mt-1 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0
            ${step.isBadPath ? 'bg-red-500' : step.isGoodPath ? 'bg-green-500' : 'bg-blue-500'}`}>
            {index + 1}
          </div>
          <div className={`p-3 border rounded-md w-full 
            ${step.type === 'decision' ? 'bg-yellow-100 dark:bg-yellow-900/30 border-yellow-400 dark:border-yellow-600' : 
              step.isBadPath ? 'bg-red-100 dark:bg-red-900/30 border-red-400 dark:border-red-600' :
              step.isGoodPath ? 'bg-green-100 dark:bg-green-900/30 border-green-400 dark:border-green-600' :
              'bg-gray-100 dark:bg-gray-700/30 border-gray-300 dark:border-gray-600'}`}>
            <strong className="text-gray-800 dark:text-gray-100">{step.name}</strong>
            {step.type === 'decision' && step.outcome && <span className="ml-2 text-xs italic bg-yellow-200 dark:bg-yellow-700 px-1.5 py-0.5 rounded text-yellow-700 dark:text-yellow-200">{step.outcome}</span>}
            {step.details && <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{step.details}</p>}
          </div>
        </div>
      ))}
    </div>
  </Section>
);

export const ScenarioCard: React.FC<ScenarioCardProps> = ({ scenario }) => {
  return (
    <article className="space-y-10">
      <Section title={scenario.title} level={1} titleColor="text-blue-600 dark:text-blue-400">
         <p className="text-lg">{scenario.introduction}</p>
      </Section>

      {/* Vulnerable Section */}
      <Section title={scenario.vulnerable.title} level={2} titleColor="text-red-600 dark:text-red-400">
        <p>{scenario.vulnerable.description}</p>
        {scenario.vulnerable.htmlFormExample && (
            <CodeDisplay snippet={scenario.vulnerable.htmlFormExample} />
        )}
        {scenario.vulnerable.codeSnippets.map((snippet, idx) => (
          <CodeDisplay key={`vuln-code-${idx}`} snippet={snippet} />
        ))}
        <h3 className="text-xl font-semibold mt-6 mb-2 text-gray-700 dark:text-gray-200">Exploit Examples:</h3>
        {scenario.vulnerable.exploitExamples.map((ex, idx) => (
          <InputOutputDisplay key={`vuln-ex-${idx}`} example={ex} />
        ))}
      </Section>

      {/* Fixed Section */}
      <Section title={scenario.fixed.title} level={2} titleColor="text-green-600 dark:text-green-400">
        <p>{scenario.fixed.description}</p>
         {scenario.fixed.htmlFormExample && (
            <CodeDisplay snippet={scenario.fixed.htmlFormExample} />
        )}
        {scenario.fixed.codeSnippets.map((snippet, idx) => (
          <CodeDisplay key={`fixed-code-${idx}`} snippet={snippet} />
        ))}
        <h3 className="text-xl font-semibold mt-6 mb-2 text-gray-700 dark:text-gray-200">Input Handling Examples:</h3>
        {scenario.fixed.inputHandlingExamples.map((ex, idx) => (
          <InputOutputDisplay key={`fixed-ex-${idx}`} example={ex} />
        ))}
      </Section>

      {/* Explanation Section */}
      <Section title={scenario.explanation.title} level={3}>
        <ul className="list-disc space-y-3 pl-5">
          {scenario.explanation.points.map((point, idx) => (
            <li key={`exp-${idx}`}>
              <strong className="text-gray-700 dark:text-gray-100">{point.title}:</strong> {point.detail}
            </li>
          ))}
        </ul>
      </Section>
      
      {/* Flow Diagram Section */}
      {scenario.flowDiagram && (
        <FlowDiagramDisplay 
          title={scenario.flowDiagram.title}
          description={scenario.flowDiagram.description}
          steps={scenario.flowDiagram.steps}
        />
      )}

      {/* Log Example Section */}
      {scenario.logExample && (
        <Section title={scenario.logExample.title} level={3}>
          {scenario.logExample.description && <p className="text-sm mb-2">{scenario.logExample.description}</p>}
          <CodeDisplay snippet={{ code: scenario.logExample.logContent, language: 'log', description: 'Log Entries:' }} />
        </Section>
      )}
    </article>
  );
};
