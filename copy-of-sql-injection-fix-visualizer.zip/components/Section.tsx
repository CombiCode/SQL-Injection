
import React from 'react';

interface SectionProps {
  title: string;
  children: React.ReactNode;
  level?: 1 | 2 | 3 | 4; // For h1, h2, h3, h4
  titleColor?: string; // Tailwind color class
}

export const Section: React.FC<SectionProps> = ({ title, children, level = 2, titleColor = 'text-gray-700 dark:text-gray-200' }) => {
  const TitleTag = `h${level}` as keyof JSX.IntrinsicElements;
  
  let titleClasses = "font-semibold mb-3 ";
  if (level === 1) titleClasses += "text-3xl md:text-4xl ";
  else if (level === 2) titleClasses += "text-2xl md:text-3xl ";
  else if (level === 3) titleClasses += "text-xl md:text-2xl ";
  else titleClasses += "text-lg md:text-xl ";
  titleClasses += titleColor;

  return (
    <section className="mb-8 p-4 md:p-6 bg-white dark:bg-gray-800 shadow-lg rounded-xl transition-colors duration-300">
      <TitleTag className={titleClasses}>{title}</TitleTag>
      <div className="space-y-4 text-gray-600 dark:text-gray-300">
        {children}
      </div>
    </section>
  );
};
