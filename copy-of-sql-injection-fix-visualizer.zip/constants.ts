
import type { ScenarioData } from './types';

export const LOGIN_SCENARIO_DATA: ScenarioData = {
  id: 'login',
  title: 'Login SQL Injection Vulnerability & Fix',
  introduction: 'This scenario demonstrates a common SQL injection vulnerability in a login form and how to mitigate it using prepared statements and input validation.',
  vulnerable: {
    title: 'Vulnerable Login (Before Fix)',
    description: 'The PHP code below directly concatenates user input into an SQL query, making it susceptible to SQL injection. An attacker can manipulate the query to bypass authentication.',
    codeSnippets: [
      {
        fileName: 'login.php (Vulnerable)',
        language: 'php',
        code: `<?php
// UNSAFE CODE - Directly using POST data in SQL query
$username = $_POST['username'];
$password = $_POST['password']; // In real vulnerable code, password might also be unsafely handled

// Example vulnerable query construction
$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
// $result = mysqli_query($conn, $query); // Example execution
// ... (rest of hypothetical vulnerable login logic) ...

// For demonstration, let's assume if query returns rows, login is successful
if (isset($username) && isset($password)) { // Simplified check
    // This part simulates a successful login if the injected query works
    if (strpos($username, "' OR 1=1 --") !== false) {
        echo json_encode(["id" => 1, "username" => "admin", "role" => "superuser", "message" => "Login successful as admin (simulated due to SQLi)"]);
    } else {
        echo json_encode(["error" => "Login failed (simulated)"]);
    }
}
?>`
      }
    ],
    htmlFormExample: {
        fileName: 'login_form_vulnerable.html',
        language: 'html',
        code: `<!-- File: login_old.html -->
<form action="login.php" method="POST">
  <input type="text" name="username" placeholder="Username"> 
  <input type="password" name="password" placeholder="Password">
  <button type="submit">Login</button>
</form>`
    },
    exploitExamples: [
      {
        label: 'Basic SQL Injection Attempt',
        inputDescription: "Attacker enters a crafted string in the username field:",
        input: `Username: ' OR 1=1 --\nPassword: (any value or empty)`,
        inputLanguage: 'text',
        outputDescription: "The vulnerable backend might execute a query like:",
        output: `SELECT * FROM users WHERE username='' OR 1=1 --' AND password='(any value)'
        
// Simulated JSON Response (Exploit Successful):
{
  "id": 1,
  "username": "admin",
  "role": "superuser",
  "message": "Login successful as admin (simulated due to SQLi)"
}`,
        outputLanguage: 'sql',
        isHarmful: true,
      }
    ]
  },
  fixed: {
    title: 'Secure Login (After Fix)',
    description: 'The vulnerability is addressed by using parameterized queries (prepared statements) and validating user input. This ensures that user-supplied data is treated as data, not as executable SQL code.',
    codeSnippets: [
      {
        fileName: 'login_secure.php (Fixed)',
        language: 'php',
        code: `<?php
// SAFE PARAMETERIZED QUERY & INPUT VALIDATION
function secure_login($conn, $username, $password_input) {
    // Input Validation (example)
    if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
        // http_response_code(400); // Set appropriate HTTP status
        return ["error" => "Invalid username format"];
    }

    // Password hashing should be done here in a real app, e.g., password_hash()
    // For this example, assuming password comparison is part of the query
    // $hashed_password = hash('sha256', $password_input); // Example hashing

    $stmt = $conn->prepare("SELECT id, username FROM users WHERE username = ? AND password_hash = ?");
    // Note: Password checking should ideally be done after fetching user by username,
    // then using password_verify() against a stored hash.
    // The query above is simplified for SQLi demonstration with parameters.
    
    $stmt->bind_param("ss", $username, $password_input); // Bind parameters (s for string)
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        return ["status" => "success", "user" => $user];
    } else {
        // http_response_code(401); // Unauthorized
        return ["error" => "Invalid username or password"];
    }
}

// Example usage:
// $user_data = secure_login($db_connection, $_POST['username'], $_POST['password']);
// echo json_encode($user_data);

// Simulated handling of the SQLi attempt from before:
if ($_POST['username'] === "' OR 1=1 --") {
     echo json_encode(["error" => "Invalid username format"]);
} else if ($_POST['username'] === 'testuser' && $_POST['password'] === 'GoodPass123') {
     echo json_encode(["status" => "success", "user" => ["id" => 42, "username" => "testuser"]]);
} else {
    echo json_encode(["error" => "Invalid username or password"]);
}
?>`
      }
    ],
    htmlFormExample: {
      fileName: 'login_form_secure.html',
      language: 'html',
      code: `<!-- File: login_new.html -->
<form action="login_secure.php" method="POST">
  <input type="text" name="username" pattern="[a-zA-Z0-9_]{3,20}" 
         title="Username must be 3-20 alphanumeric characters or underscores." required>
  <input type="password" name="password" minlength="8" required>
  <button type="submit">Login</button>
</form>`
    },
    inputHandlingExamples: [
      {
        label: 'Attempting SQL Injection on Fixed Code',
        inputDescription: "Attacker tries the same payload:",
        input: `Username: ' OR 1=1 --\nPassword: (any value or empty)`,
        inputLanguage: 'text',
        outputDescription: "The application's behavior:",
        output: `// Input Validation (preg_match) fails:
{
  "error": "Invalid username format"
}
// Even if validation was bypassed, parameterized query would treat the input as a literal string,
// searching for a username that literally is "' OR 1=1 --", which likely won't exist.
// Result: Login fails securely.`,
        outputLanguage: 'json',
        isHarmful: true,
      },
      {
        label: 'Valid Login Attempt on Fixed Code',
        inputDescription: "A legitimate user logs in:",
        input: `Username: testuser\nPassword: GoodPass123`,
        inputLanguage: 'text',
        outputDescription: "The application's behavior:",
        output: `// Secure query executed, parameters bound safely.
{
  "status": "success",
  "user": {
    "id": 42,
    "username": "testuser"
  }
}`,
        outputLanguage: 'json',
        isHarmful: false,
      }
    ]
  },
  explanation: {
    title: 'Key Security Measures Implemented',
    points: [
      { title: 'Parameterized Queries (Prepared Statements)', detail: 'User input is sent to the database separately from the SQL command. The database engine then combines them, ensuring the input is treated strictly as data, not as part of the SQL command. This is the primary defense against SQLi.' },
      { title: 'Input Validation (Server-Side)', detail: 'Before processing, inputs are checked against expected formats (e.g., username pattern, length). While not a foolproof SQLi defense on its own, it helps reject malformed/malicious data early and enforces data integrity.' },
      { title: 'Client-Side Validation', detail: 'HTML5 attributes (pattern, required, minlength) provide immediate feedback to users but are easily bypassed. They improve UX but are NOT a security measure.' },
      { title: 'Principle of Least Privilege', detail: 'Database users should only have the minimum necessary permissions for their tasks. For example, a web application user might only have SELECT, INSERT, UPDATE permissions on specific tables, not DROP TABLE.' },
      { title: 'Secure Password Handling', detail: 'Passwords must be hashed using strong, modern algorithms (e.g., Argon2, bcrypt) before storing. Comparisons are done against these hashes. (This point is broader than SQLi but crucial for login security).' }
    ]
  },
  flowDiagram: {
    title: 'Simplified Secure Login Flow',
    description: 'Illustrates the process from user input to database interaction with security checks in place.',
    steps: [
      { name: 'User Submits Login Form', type: 'io', details: 'Username & Password sent' },
      { name: 'Server Receives Data', type: 'process' },
      { name: 'Validate Input (e.g., format, length)', type: 'decision', outcome: 'Valid / Invalid' },
      { name: 'IF INVALID: Reject & Log Attempt', type: 'terminator', isBadPath: true, details: 'e.g., "Invalid username format"' },
      { name: 'IF VALID: Proceed', type: 'connector', isGoodPath: true },
      { name: 'Prepare SQL Query (with placeholders)', type: 'process', isGoodPath: true, details: 'e.g., SELECT ... WHERE username = ?' },
      { name: 'Bind User Input as Parameters', type: 'process', isGoodPath: true, details: 'Input treated as data' },
      { name: 'Execute Prepared Statement', type: 'process', isGoodPath: true },
      { name: 'Check Result', type: 'decision', outcome: 'User Found / Not Found', isGoodPath: true },
      { name: 'IF USER FOUND: Authenticate (e.g., verify password hash), Grant Access', type: 'io', isGoodPath: true },
      { name: 'IF NOT FOUND: Deny Access', type: 'io', isBadPath: true, details: 'e.g., "Invalid credentials"' }
    ]
  },
  logExample: {
    title: 'Example Security Log Output for Login Attempts',
    description: 'Effective logging helps in monitoring and responding to potential attacks.',
    logContent: `[2023-11-20 14:30:45] WARNING: SQLi attempt on login - User: "' OR 1=1 --", IP: 192.168.1.100, Reason: Invalid username format.
[2023-11-20 14:31:02] INFO: Successful login - User: testuser, IP: 192.168.1.101.
[2023-11-20 14:32:15] NOTICE: Failed login attempt - User: attacker, IP: 192.168.1.102, Reason: Invalid credentials.`
  }
};

export const SEARCH_SCENARIO_DATA: ScenarioData = {
  id: 'search',
  title: 'Search Function SQL Injection & Fix',
  introduction: 'Search functionalities are also common targets for SQL injection if user input is not handled correctly. This scenario shows a vulnerability in a search query and its remediation.',
  vulnerable: {
    title: 'Vulnerable Search (Before Fix)',
    description: 'The search functionality directly incorporates user input into a LIKE clause, opening it up to SQL injection that could lead to data exposure or manipulation.',
    codeSnippets: [
      {
        fileName: 'search.php (Vulnerable)',
        language: 'php',
        code: `<?php
// UNSAFE CODE - User input in LIKE clause
$search_query = $_POST['query'];

// Example vulnerable query construction
$sql = "SELECT * FROM products WHERE name LIKE '%$search_query%'";
// $result = mysqli_query($conn, $sql);
// ... (rest of hypothetical vulnerable search logic) ...

// Simplified simulation for exploit
if (strpos($search_query, "%' OR '1'='1") !== false) {
    echo json_encode([
        ["id"=>1, "name"=>"Laptop", "price"=>1200], 
        ["id"=>2, "name"=>"Mouse", "price"=>25], 
        ["id"=>3, "name"=>"Keyboard", "price"=>75],
        ["message" => "All products listed due to SQLi (simulated)"]
    ]);
} else if (!empty($search_query)) {
    echo json_encode([["id"=>1, "name"=>"Laptop X", "price"=>1200, "message" => "Filtered results (simulated)"]]);
} else {
    echo json_encode(["error" => "No search term provided (simulated)"]);
}
?>`
      }
    ],
     htmlFormExample: {
        fileName: 'search_form_vulnerable.html',
        language: 'html',
        code: `<!-- File: search_old.html -->
<form action="search.php" method="POST">
  <input type="text" name="query" placeholder="Search products...">
  <button type="submit">Search</button>
</form>`
    },
    exploitExamples: [
      {
        label: 'SQL Injection to Dump Data',
        inputDescription: "Attacker uses a payload to alter the LIKE clause and retrieve more data:",
        input: `Search Query: %' OR '1'='1`,
        inputLanguage: 'text',
        outputDescription: "The vulnerable backend might execute a query like:",
        output: `SELECT * FROM products WHERE name LIKE '%%' OR '1'='1%' 
// This effectively becomes 'anything' OR TRUE, potentially returning all rows.

// Simulated JSON Response (Exploit Successful):
[
  {"id":1, "name":"Laptop", "price":1200}, 
  {"id":2, "name":"Mouse", "price":25}, 
  {"id":3, "name":"Keyboard", "price":75},
  {"message": "All products listed due to SQLi (simulated)"}
]`,
        outputLanguage: 'sql',
        isHarmful: true,
      }
    ]
  },
  fixed: {
    title: 'Secure Search (After Fix)',
    description: 'The fix involves using parameterized queries for the LIKE clause and sanitizing/escaping special LIKE characters if necessary (though parameterization usually handles this).',
    codeSnippets: [
      {
        fileName: 'search_secure.php (Fixed)',
        language: 'php',
        code: `<?php
// SAFE PARAMETERIZED QUERY for SEARCH
function secure_search($conn, $search_term) {
    // Basic input cleaning (optional, as prepared statements handle SQLi)
    $search_term = trim($search_term);
    if (empty($search_term)) {
        return ["error" => "Search term cannot be empty"];
    }
    // For LIKE clauses, percent signs need to be part of the bound parameter
    $param = "%" . $search_term . "%";

    $stmt = $conn->prepare("SELECT id, name, price FROM products WHERE name LIKE ?");
    $stmt->bind_param("s", $param);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    if (count($products) > 0) {
        return $products;
    } else {
        return ["message" => "No products found matching your search."];
    }
}

// Example usage:
// $search_results = secure_search($db_connection, $_POST['query']);
// echo json_encode($search_results);

// Simulated handling of the SQLi attempt from before:
if ($_POST['query'] === "%' OR '1'='1") {
     echo json_encode(["message" => "No products found matching your search."]); // Simulates no match for the literal string
} else if ($_POST['query'] === 'Laptop') {
     echo json_encode([["id" => 1, "name" => "Laptop X", "price" => 1200]]);
} else {
    echo json_encode(["message" => "No products found."]);
}
?>`
      }
    ],
    htmlFormExample: {
      fileName: 'search_form_secure.html',
      language: 'html',
      code: `<!-- File: search_new.html -->
<form action="search_secure.php" method="POST">
  <input type="text" name="query" maxlength="100" 
         placeholder="Search products..." required>
  <button type="submit">Search</button>
</form>`
    },
    inputHandlingExamples: [
      {
        label: 'Attempting SQL Injection on Fixed Search',
        inputDescription: "Attacker tries the same payload:",
        input: `Search Query: %' OR '1'='1`,
        inputLanguage: 'text',
        outputDescription: "The application's behavior:",
        output: `// The input "%' OR '1'='1" is treated as a literal string to search for.
// The query becomes effectively: SELECT ... WHERE name LIKE '%(%' OR '1'='1)%'
// This will likely find no matching product names.

// Simulated JSON Response:
{
  "message": "No products found matching your search."
}`,
        outputLanguage: 'json',
        isHarmful: true,
      },
      {
        label: 'Valid Search on Fixed Code',
        inputDescription: "A legitimate user searches:",
        input: `Search Query: Laptop`,
        inputLanguage: 'text',
        outputDescription: "The application's behavior:",
        output: `// Secure query executed: SELECT ... WHERE name LIKE '%Laptop%'
// Simulated JSON Response:
[
  {"id": 1, "name": "Laptop X", "price": 1200}
]`,
        outputLanguage: 'json',
        isHarmful: false,
      }
    ]
  },
  explanation: {
    title: 'Securing Search Functionality',
    points: [
      { title: 'Parameterized LIKE Clauses', detail: 'Similar to other queries, use prepared statements. The wildcard characters (%) for LIKE should be concatenated with the user input variable *before* binding, or bound as separate parameters if the driver supports it.' },
      { title: 'Escaping LIKE Wildcards (If needed)', detail: 'If users need to search for literal % or _ characters, these would need specific escaping (e.g., LIKE \'%\%%\' ESCAPE \'\\\') in addition to parameterized queries. Most ORMs/drivers handle this transparently with parameters.' },
      { title: 'Limit Results & Input Length', detail: 'Always limit the number of search results returned (pagination). Restrict the maximum length of search queries to prevent overly broad or resource-intensive searches.' },
      { title: 'Full-Text Search Engines', detail: 'For complex search requirements, consider dedicated full-text search engines (e.g., Elasticsearch, Solr). These often have their own query languages and security considerations but are optimized for search.' }
    ]
  },
   flowDiagram: {
    title: 'Simplified Secure Search Flow',
    description: 'Data flow for a search query with SQLi prevention.',
    steps: [
      { name: 'User Enters Search Term', type: 'io' },
      { name: 'Server Receives Search Term', type: 'process' },
      { name: 'Sanitize/Validate Input (e.g., length, basic cleaning)', type: 'process', details: 'Optional, as parameters are key' },
      { name: 'Prepare SQL LIKE Query (with placeholders)', type: 'process', isGoodPath: true, details: 'e.g., SELECT ... WHERE name LIKE ?' },
      { name: 'Construct Parameter for LIKE (add % wildcards)', type: 'process', isGoodPath: true, details: 'e.g., $param = "%" . $term . "%" ' },
      { name: 'Bind Search Parameter', type: 'process', isGoodPath: true },
      { name: 'Execute Prepared Statement', type: 'process', isGoodPath: true },
      { name: 'Return Search Results (or "No results found")', type: 'io', isGoodPath: true }
    ]
  },
  logExample: {
    title: 'Example Log for Search Activity',
    description: 'Logging search terms can be useful, but be mindful of PII if search terms might contain sensitive data.',
    logContent: `[2023-11-20 15:00:10] INFO: Search performed - Term: "Laptop", IP: 192.168.1.105, Results: 5.
[2023-11-20 15:01:20] NOTICE: Search performed - Term: "%' OR '1'='1", IP: 192.168.1.106, Results: 0 (Potentially suspicious input pattern noted).`
  }
};
