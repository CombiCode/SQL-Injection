
export interface CodeSnippetContent {
  description?: string;
  language: string;
  code: string;
  fileName?: string;
}

export interface InputOutputExample {
  label: string;
  inputDescription?: string;
  input: string;
  inputLanguage?: string;
  outputDescription?: string;
  output: string;
  outputLanguage?: string;
  isHarmful: boolean;
}

export interface FixExplanationContent {
  title: string;
  points: Array<{ title: string, detail: string }>;
}

export interface FlowStep {
  name: string;
  type: 'io' | 'process' | 'decision' | 'terminator' | 'connector';
  details?: string;
  outcome?: string; // For decision branches
  isGoodPath?: boolean;
  isBadPath?: boolean;
}

export interface ScenarioData {
  id: string;
  title: string;
  introduction: string;
  vulnerable: {
    title: string;
    description: string;
    codeSnippets: CodeSnippetContent[];
    exploitExamples: InputOutputExample[];
    htmlFormExample?: CodeSnippetContent;
  };
  fixed: {
    title: string;
    description: string;
    codeSnippets: CodeSnippetContent[];
    inputHandlingExamples: InputOutputExample[];
    htmlFormExample?: CodeSnippetContent;
  };
  explanation: FixExplanationContent;
  flowDiagram?: {
    title: string;
    description: string;
    steps: FlowStep[];
  };
  logExample?: {
    title: string;
    description?: string;
    logContent: string;
  };
}
